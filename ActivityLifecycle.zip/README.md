Android Activity Lifecycle
==========================

This sample app accompanies the article, 
[Walkthrough - Saving the Activity State](http://developer.xamarin.com/guides/android/application_fundamentals/activity_lifecycle/saving_state_walkthrough).


[ ![](Screenshots/example-screenshot-sml.png)](Screenshots/example-screenshot.png)
